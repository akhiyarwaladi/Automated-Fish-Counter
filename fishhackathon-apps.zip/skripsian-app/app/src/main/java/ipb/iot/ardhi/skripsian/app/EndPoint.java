package ipb.iot.ardhi.skripsian.app;

/**
 * Created by erdearik on 3/8/16.
 */
public class EndPoint {
    public static final String BASE_URL = "http://192.168.43.33/fishhackathon/v1/tasks";
//    public static final String BASE_URL = "http://enigmatech.id/fish/v1/tasks";
    public static final String LOGIN = BASE_URL + "/user/login";
    public static final String USER = BASE_URL + "/user/_ID_";
    public static final String CHAT_ROOMS = BASE_URL + "/chat_rooms";
    public static final String CHAT_THREAD = BASE_URL + "/chat_rooms/_ID_";
    public static final String CHAT_ROOM_MESSAGE = BASE_URL + "/chat_rooms/_ID_/message";
}
