package ipb.iot.ardhi.skripsian.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import ipb.iot.ardhi.skripsian.R;
import ipb.iot.ardhi.skripsian.adapter.AllLogAdapter;
import ipb.iot.ardhi.skripsian.app.EndPoint;
import ipb.iot.ardhi.skripsian.app.MyApplication;
import ipb.iot.ardhi.skripsian.helper.MyPreferenceManager;
import ipb.iot.ardhi.skripsian.model.AllData;

/**
 * A simple {@link Fragment} subclass.
 */
public class LogWarningFragment extends Fragment {


    private String TAG = LogAllFragment.class.getSimpleName();
    private ListView lv;
    private AllLogAdapter mAdapter;
    private RecyclerView recyclerView;

    public LogWarningFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_log_warning, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view_warn);
        MyPreferenceManager.warnDataArrayList = new ArrayList<>();
        mAdapter = new AllLogAdapter(getActivity(),MyPreferenceManager.warnDataArrayList);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        return view;
    }

//    private void fetchChatRooms() {
//        StringRequest stringRequest = new StringRequest(Request.Method.GET,
//                EndPoint.BASE_URL, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//                Log.e(TAG, "onResponse: " + response);
//                try {
//                    JSONObject obj = new JSONObject(response);
//
//                    if (obj.getBoolean("error") == false) {
//                        JSONArray data = obj.getJSONArray("tasks");
//                        for (int i = 0; i < data.length(); i++) {
//                            JSONObject dataObj = (JSONObject) data.get(i);
//                            if(dataObj.getString("status").equals("1")){
//                                AllData ad = new AllData();
//                                ad.setId(dataObj.getString("id"));
//                                ad.setPh(dataObj.getString("sensor1"));
//                                ad.setSuhu(dataObj.getString("sensor2"));
//                                ad.setDoo(dataObj.getString("sensor3"));
//                                ad.setOutput(dataObj.getString("output"));
//                                ad.setWaktu(dataObj.getString("createdAt"));
//                                ad.setStatus(String.valueOf(i));
//
//                                MyPreferenceManager.warnDataArrayList.add(ad);
//                            }
//                        }
//                    } else {
//                        // error in fetching data
//                        Toast.makeText(getActivity(), "" + obj.getJSONObject("error").getString("message"), Toast.LENGTH_LONG).show();
//                    }
//                } catch (JSONException e) {
//                    Log.e(TAG, "json parsing error: " + e.getMessage());
//                    Toast.makeText(getActivity(), "Json parse error: " + e.getMessage(), Toast.LENGTH_LONG).show();
//                }
//                mAdapter.notifyDataSetChanged();
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                NetworkResponse networkResponse = error.networkResponse;
//                Log.e(TAG, "Volley error: " + error.getMessage() + ", code: " + networkResponse);
//                Toast.makeText(getActivity(), "Volley errror: " + error.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//        //Adding request to request queue
//        MyApplication.getInstance().addToRequestQueue(stringRequest);
//    }
}
