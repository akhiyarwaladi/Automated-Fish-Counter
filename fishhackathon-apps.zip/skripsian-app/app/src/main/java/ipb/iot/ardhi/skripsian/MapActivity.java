package ipb.iot.ardhi.skripsian;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

import ipb.iot.ardhi.skripsian.R;
import ipb.iot.ardhi.skripsian.helper.MyPreferenceManager;
import ipb.iot.ardhi.skripsian.model.AllData;

/**
 * Created by erdearik on 4/24/16.
 */
public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ArrayList<AllData> dataaa = new ArrayList<>();
    private ArrayList<MarkerOptions> mark = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        dataaa = MyPreferenceManager.allDataArrayList;

        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng last = null;
        for (int  x = 0; x < dataaa.size();x++ ){
            LatLng l = new LatLng(Float.valueOf(dataaa.get(x).getDoo()), Float.valueOf(dataaa.get(x).getOutput()));
            last = l;

            String deskrib = "Data " + x +"\\n  ";

            TextView snippet = new TextView(this);
            snippet.setTextColor(Color.BLUE);
            snippet.setText(deskrib);

            MarkerOptions marker = new MarkerOptions()
                    .position(l)
                    .title("Data id ke-"+dataaa.get(x).getId())
                    .snippet("waktu:"+dataaa.get(x).getWaktu()+"; Jumlah Ikan: "+dataaa.get(x).getPh()+"; Rata-rata ukuran: "+dataaa.get(x).getSuhu())
                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_logo));
            mMap.addMarker(marker);
            mMap.addCircle(new CircleOptions().center(l).radius(50000).strokeColor(Color.GREEN).fillColor(Color.argb(64,0,255,0)));
        }
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(last, 9));
//        final CameraPosition akhir = CameraPosition.builder().target(last).zoom(10).bearing(0).tilt(45).build();
//        flyTo(akhir);


        // Add a marker in Sydney and move the camera
//        float lat = (float) Float.valueOf(dataaa.get(2).getDoo());
//        float lang = (float) Float.valueOf(dataaa.get(2).getOutput());
//        LatLng sydney = new LatLng(lat, lang);
//        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Indonesia"));
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }

    private void flyTo(CameraPosition akhir) {
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(akhir));
    }
}
